README : 

// Auteur : Djebien Tarik
// Date    : 19 janvier 2011
// Objet  : programmation logique - introduction à prolog

Ci-Joint le TP numero 1 de Programmation logique de ELFE, tout est fonctionnel :

Arborescence de l'archive Tarik_Djebien_GROUPE4.tar.gz :
    |
    |_____README.txt
    |_____jalousie.pl 
    |_____entreprise.pl
    

Pour les commentaires :

tarik.djebien@etudiant.univ-lille1.fr

Cordialement.
