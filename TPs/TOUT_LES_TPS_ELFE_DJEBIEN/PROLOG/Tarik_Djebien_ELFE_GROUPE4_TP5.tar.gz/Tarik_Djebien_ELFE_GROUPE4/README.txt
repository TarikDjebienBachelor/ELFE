README : 

// Auteur : Djebien Tarik
// Date    : 16 février 2011
// Objet  : programmation logique - Recursivite terminale

Ci-Joint le TP numero 5 de Programmation logique de ELFE, tout est fonctionnel sauf la question 22.3 :

Arborescence de l'archive Tarik_Djebien_ELFE_GROUPE4.tar.gz :
    |
    |_____README.txt
    |_____Concatenation.pl (source PROLOG édité sous Emacs sur la Partie I du TP).
    |_____RecursiviteTerminaleEmballeurs.pl (source PROLOG édité sous Emacs sur la Partie II du TP).
    |_____EvaluationExpressionArithmetiques.pl (source PROLOG édité sous Emacs sur la Partie III du TP).
    |_____Vecteurs.pl (source PROLOG édité sous Emacs sur la Partie IV du TP).
    |_____Graphes.pl (source PROLOG édité sous Emacs sur la Partie V du TP).

Pour les commentaires :

tarik.djebien@etudiant.univ-lille1.fr

Cordialement.
