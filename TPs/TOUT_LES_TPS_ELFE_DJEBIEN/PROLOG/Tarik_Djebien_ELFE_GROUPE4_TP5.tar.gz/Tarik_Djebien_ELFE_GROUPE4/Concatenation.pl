
accoler([],L,L).
accoler([T|Q],L2,[T|L3]):-accoler(Q,L2,L3).

% Question 1

prefixe(P,L) :- accoler(P,_,L).

/*
?- prefixe(P,[u,n,p,e,t,i,t,t,e,s,t]).
P = [] ;
P = [u] ;
P = [u, n] ;
P = [u, n, p] ;
P = [u, n, p, e] ;
P = [u, n, p, e, t] ;
P = [u, n, p, e, t, i] ;
P = [u, n, p, e, t, i, t] ;
P = [u, n, p, e, t, i, t, t] ;
P = [u, n, p, e, t, i, t, t, e] ;
P = [u, n, p, e, t, i, t, t, e|...] ;
P = [u, n, p, e, t, i, t, t, e|...] ;
fail.

*/

% Question 2

suffixe(S,L) :- accoler(_,S,L).

/*
?- suffixe(S,[u,n,p,e,t,i,t,t,e,s,t]).
S = [u, n, p, e, t, i, t, t, e|...] ;
S = [n, p, e, t, i, t, t, e, s|...] ;
S = [p, e, t, i, t, t, e, s, t] ;
S = [e, t, i, t, t, e, s, t] ;
S = [t, i, t, t, e, s, t] ;
S = [i, t, t, e, s, t] ;
S = [t, t, e, s, t] ;
S = [t, e, s, t] ;
S = [e, s, t] ;
S = [s, t] ;
S = [t] ;
S = [] ;
fail.

*/

% Question 3

/*
[trace]  ?- prefixe(P,[u,n,p,e,t,i,t,t,e,s,t]).
   Call: (7) prefixe(_G345, [u, n, p, e, t, i, t, t|...]) ? creep
   Call: (8) accoler(_G345, _L212, [u, n, p, e, t, i, t, t|...]) ? creep
   Exit: (8) accoler([], [u, n, p, e, t, i, t, t|...], [u, n, p, e, t, i, t, t|...]) ? creep
   Exit: (7) prefixe([], [u, n, p, e, t, i, t, t|...]) ? creep
P = [] ;
   Redo: (8) accoler(_G345, _L212, [u, n, p, e, t, i, t, t|...]) ? creep
   Call: (9) accoler(_G444, _L212, [n, p, e, t, i, t, t, e|...]) ? creep
   Exit: (9) accoler([], [n, p, e, t, i, t, t, e|...], [n, p, e, t, i, t, t, e|...]) ? creep
   Exit: (8) accoler([u], [n, p, e, t, i, t, t, e|...], [u, n, p, e, t, i, t, t|...]) ? creep
   Exit: (7) prefixe([u], [u, n, p, e, t, i, t, t|...]) ? creep
P = [u] ;
   Redo: (9) accoler(_G444, _L212, [n, p, e, t, i, t, t, e|...]) ? creep
   Call: (10) accoler(_G447, _L212, [p, e, t, i, t, t, e, s|...]) ? creep
   Exit: (10) accoler([], [p, e, t, i, t, t, e, s|...], [p, e, t, i, t, t, e, s|...]) ? creep
   Exit: (9) accoler([n], [p, e, t, i, t, t, e, s|...], [n, p, e, t, i, t, t, e|...]) ? creep
   Exit: (8) accoler([u, n], [p, e, t, i, t, t, e, s|...], [u, n, p, e, t, i, t, t|...]) ? creep
   Exit: (7) prefixe([u, n], [u, n, p, e, t, i, t, t|...]) ? creep
P = [u, n] ;
   Redo: (10) accoler(_G447, _L212, [p, e, t, i, t, t, e, s|...]) ? creep
   Call: (11) accoler(_G450, _L212, [e, t, i, t, t, e, s, t]) ? creep
   Exit: (11) accoler([], [e, t, i, t, t, e, s, t], [e, t, i, t, t, e, s, t]) ? creep
   Exit: (10) accoler([p], [e, t, i, t, t, e, s, t], [p, e, t, i, t, t, e, s|...]) ? creep
   Exit: (9) accoler([n, p], [e, t, i, t, t, e, s, t], [n, p, e, t, i, t, t, e|...]) ? creep
   Exit: (8) accoler([u, n, p], [e, t, i, t, t, e, s, t], [u, n, p, e, t, i, t, t|...]) ? creep
   Exit: (7) prefixe([u, n, p], [u, n, p, e, t, i, t, t|...]) ? creep
P = [u, n, p] ;
   Redo: (11) accoler(_G450, _L212, [e, t, i, t, t, e, s, t]) ? creep
   Call: (12) accoler(_G453, _L212, [t, i, t, t, e, s, t]) ? creep
   Exit: (12) accoler([], [t, i, t, t, e, s, t], [t, i, t, t, e, s, t]) ? creep
   Exit: (11) accoler([e], [t, i, t, t, e, s, t], [e, t, i, t, t, e, s, t]) ? creep
   Exit: (10) accoler([p, e], [t, i, t, t, e, s, t], [p, e, t, i, t, t, e, s|...]) ? creep
   Exit: (9) accoler([n, p, e], [t, i, t, t, e, s, t], [n, p, e, t, i, t, t, e|...]) ? creep
   Exit: (8) accoler([u, n, p, e], [t, i, t, t, e, s, t], [u, n, p, e, t, i, t, t|...]) ? creep
   Exit: (7) prefixe([u, n, p, e], [u, n, p, e, t, i, t, t|...]) ? creep
P = [u, n, p, e] ;
   Redo: (12) accoler(_G453, _L212, [t, i, t, t, e, s, t]) ? creep
   Call: (13) accoler(_G456, _L212, [i, t, t, e, s, t]) ? creep
   Exit: (13) accoler([], [i, t, t, e, s, t], [i, t, t, e, s, t]) ? creep
   Exit: (12) accoler([t], [i, t, t, e, s, t], [t, i, t, t, e, s, t]) ? creep
   Exit: (11) accoler([e, t], [i, t, t, e, s, t], [e, t, i, t, t, e, s, t]) ? creep
   Exit: (10) accoler([p, e, t], [i, t, t, e, s, t], [p, e, t, i, t, t, e, s|...]) ? creep
   Exit: (9) accoler([n, p, e, t], [i, t, t, e, s, t], [n, p, e, t, i, t, t, e|...]) ? creep
   Exit: (8) accoler([u, n, p, e, t], [i, t, t, e, s, t], [u, n, p, e, t, i, t, t|...]) ? creep
   Exit: (7) prefixe([u, n, p, e, t], [u, n, p, e, t, i, t, t|...]) ? creep
P = [u, n, p, e, t] ;
   Redo: (13) accoler(_G456, _L212, [i, t, t, e, s, t]) ? creep
   Call: (14) accoler(_G459, _L212, [t, t, e, s, t]) ? creep
   Exit: (14) accoler([], [t, t, e, s, t], [t, t, e, s, t]) ? creep
   Exit: (13) accoler([i], [t, t, e, s, t], [i, t, t, e, s, t]) ? creep
   Exit: (12) accoler([t, i], [t, t, e, s, t], [t, i, t, t, e, s, t]) ? creep
   Exit: (11) accoler([e, t, i], [t, t, e, s, t], [e, t, i, t, t, e, s, t]) ? creep
   Exit: (10) accoler([p, e, t, i], [t, t, e, s, t], [p, e, t, i, t, t, e, s|...]) ? creep
   Exit: (9) accoler([n, p, e, t, i], [t, t, e, s, t], [n, p, e, t, i, t, t, e|...]) ? creep
   Exit: (8) accoler([u, n, p, e, t, i], [t, t, e, s, t], [u, n, p, e, t, i, t, t|...]) ? creep
   Exit: (7) prefixe([u, n, p, e, t, i], [u, n, p, e, t, i, t, t|...]) ? creep
P = [u, n, p, e, t, i] ;
   Redo: (14) accoler(_G459, _L212, [t, t, e, s, t]) ? creep
   Call: (15) accoler(_G462, _L212, [t, e, s, t]) ? creep
   Exit: (15) accoler([], [t, e, s, t], [t, e, s, t]) ? creep
   Exit: (14) accoler([t], [t, e, s, t], [t, t, e, s, t]) ? creep
   Exit: (13) accoler([i, t], [t, e, s, t], [i, t, t, e, s, t]) ? creep
   Exit: (12) accoler([t, i, t], [t, e, s, t], [t, i, t, t, e, s, t]) ? creep
   Exit: (11) accoler([e, t, i, t], [t, e, s, t], [e, t, i, t, t, e, s, t]) ? creep
   Exit: (10) accoler([p, e, t, i, t], [t, e, s, t], [p, e, t, i, t, t, e, s|...]) ? creep
   Exit: (9) accoler([n, p, e, t, i, t], [t, e, s, t], [n, p, e, t, i, t, t, e|...]) ? creep
   Exit: (8) accoler([u, n, p, e, t, i, t], [t, e, s, t], [u, n, p, e, t, i, t, t|...]) ? creep
   Exit: (7) prefixe([u, n, p, e, t, i, t], [u, n, p, e, t, i, t, t|...]) ? creep
P = [u, n, p, e, t, i, t] ;
   Redo: (15) accoler(_G462, _L212, [t, e, s, t]) ? creep
   Call: (16) accoler(_G465, _L212, [e, s, t]) ? creep
   Exit: (16) accoler([], [e, s, t], [e, s, t]) ? creep
   Exit: (15) accoler([t], [e, s, t], [t, e, s, t]) ? creep
   Exit: (14) accoler([t, t], [e, s, t], [t, t, e, s, t]) ? creep
   Exit: (13) accoler([i, t, t], [e, s, t], [i, t, t, e, s, t]) ? creep
   Exit: (12) accoler([t, i, t, t], [e, s, t], [t, i, t, t, e, s, t]) ? creep
   Exit: (11) accoler([e, t, i, t, t], [e, s, t], [e, t, i, t, t, e, s, t]) ? creep
   Exit: (10) accoler([p, e, t, i, t, t], [e, s, t], [p, e, t, i, t, t, e, s|...]) ? creep
   Exit: (9) accoler([n, p, e, t, i, t, t], [e, s, t], [n, p, e, t, i, t, t, e|...]) ? creep
   Exit: (8) accoler([u, n, p, e, t, i, t, t], [e, s, t], [u, n, p, e, t, i, t, t|...]) ? creep
   Exit: (7) prefixe([u, n, p, e, t, i, t, t], [u, n, p, e, t, i, t, t|...]) ? creep
P = [u, n, p, e, t, i, t, t] ;
   Redo: (16) accoler(_G465, _L212, [e, s, t]) ? creep
   Call: (17) accoler(_G468, _L212, [s, t]) ? creep
   Exit: (17) accoler([], [s, t], [s, t]) ? creep
   Exit: (16) accoler([e], [s, t], [e, s, t]) ? creep
   Exit: (15) accoler([t, e], [s, t], [t, e, s, t]) ? creep
   Exit: (14) accoler([t, t, e], [s, t], [t, t, e, s, t]) ? creep
   Exit: (13) accoler([i, t, t, e], [s, t], [i, t, t, e, s, t]) ? creep
   Exit: (12) accoler([t, i, t, t, e], [s, t], [t, i, t, t, e, s, t]) ? creep
   Exit: (11) accoler([e, t, i, t, t, e], [s, t], [e, t, i, t, t, e, s, t]) ? creep
   Exit: (10) accoler([p, e, t, i, t, t, e], [s, t], [p, e, t, i, t, t, e, s|...]) ? creep
   Exit: (9) accoler([n, p, e, t, i, t, t, e], [s, t], [n, p, e, t, i, t, t, e|...]) ? creep
   Exit: (8) accoler([u, n, p, e, t, i, t, t|...], [s, t], [u, n, p, e, t, i, t, t|...]) ? creep
   Exit: (7) prefixe([u, n, p, e, t, i, t, t|...], [u, n, p, e, t, i, t, t|...]) ? creep
P = [u, n, p, e, t, i, t, t, e] ;
   Redo: (17) accoler(_G468, _L212, [s, t]) ? creep
   Call: (18) accoler(_G471, _L212, [t]) ? creep
   Exit: (18) accoler([], [t], [t]) ? creep
   Exit: (17) accoler([s], [t], [s, t]) ? creep
   Exit: (16) accoler([e, s], [t], [e, s, t]) ? creep
   Exit: (15) accoler([t, e, s], [t], [t, e, s, t]) ? creep
   Exit: (14) accoler([t, t, e, s], [t], [t, t, e, s, t]) ? creep
   Exit: (13) accoler([i, t, t, e, s], [t], [i, t, t, e, s, t]) ? creep
   Exit: (12) accoler([t, i, t, t, e, s], [t], [t, i, t, t, e, s, t]) ? creep
   Exit: (11) accoler([e, t, i, t, t, e, s], [t], [e, t, i, t, t, e, s, t]) ? creep
   Exit: (10) accoler([p, e, t, i, t, t, e, s], [t], [p, e, t, i, t, t, e, s|...]) ? creep
   Exit: (9) accoler([n, p, e, t, i, t, t, e|...], [t], [n, p, e, t, i, t, t, e|...]) ? creep
   Exit: (8) accoler([u, n, p, e, t, i, t, t|...], [t], [u, n, p, e, t, i, t, t|...]) ? creep
   Exit: (7) prefixe([u, n, p, e, t, i, t, t|...], [u, n, p, e, t, i, t, t|...]) ? creep
P = [u, n, p, e, t, i, t, t, e|...] ;
   Redo: (18) accoler(_G471, _L212, [t]) ? creep
   Call: (19) accoler(_G474, _L212, []) ? creep
   Exit: (19) accoler([], [], []) ? creep
   Exit: (18) accoler([t], [], [t]) ? creep
   Exit: (17) accoler([s, t], [], [s, t]) ? creep
   Exit: (16) accoler([e, s, t], [], [e, s, t]) ? creep
   Exit: (15) accoler([t, e, s, t], [], [t, e, s, t]) ? creep
   Exit: (14) accoler([t, t, e, s, t], [], [t, t, e, s, t]) ? creep
   Exit: (13) accoler([i, t, t, e, s, t], [], [i, t, t, e, s, t]) ? creep
   Exit: (12) accoler([t, i, t, t, e, s, t], [], [t, i, t, t, e, s, t]) ? creep
   Exit: (11) accoler([e, t, i, t, t, e, s, t], [], [e, t, i, t, t, e, s, t]) ? creep
   Exit: (10) accoler([p, e, t, i, t, t, e, s|...], [], [p, e, t, i, t, t, e, s|...]) ? creep
   Exit: (9) accoler([n, p, e, t, i, t, t, e|...], [], [n, p, e, t, i, t, t, e|...]) ? creep
   Exit: (8) accoler([u, n, p, e, t, i, t, t|...], [], [u, n, p, e, t, i, t, t|...]) ? creep
   Exit: (7) prefixe([u, n, p, e, t, i, t, t|...], [u, n, p, e, t, i, t, t|...]) ? creep
P = [u, n, p, e, t, i, t, t, e|...] ;
   Redo: (19) accoler(_G474, _L212, []) ? creep
   Fail: (7) prefixe(_G345, [u, n, p, e, t, i, t, t|...]) ? creep
fail.

*/

% PROLOG unifie d'abord _L212 dans la regle  accoler(_G345, _L212, [u, n, p, e, t, i, t, t|...])
% avec _L212 = L =  [u, n, p, e, t, i, t, t|...] la liste complete.
% donc accoler/3 tente d'unifier _G345 avec une Liste qui concaténé avec L donne L donc le seul cas possible
% est la liste vide.
% P = []
% Ensuite PROLOG backtrack dans l'arbre de resolution mais en decalant d'une lettre une par une dans L
% P augmente donc jusque P=L
% On obtient donc d'abord les listes les plus courtes et ensuite les plus longues.

% Pour le prédicat suffixe/2 , accoler/3 prend d'abord la liste vide dans  accoler(_G345, _L212, [])
% donc la premiere solution dans l'arbre de resolution nous donne _G345 = L = S
% ensuite PROLOG backtrack dans l'arbre en ajoutant a chaque fois une lettre.
% S diminue donc jusqye S= [].

% Question 4

sousliste(SubL,L):-suffixe(S,L),prefixe(SubL,S).

/*
?- sousliste(X,[1,2,3,4,5]).
X = [] ;
X = [1] ;
X = [1, 2] ;
X = [1, 2, 3] ;
X = [1, 2, 3, 4] ;
X = [1, 2, 3, 4, 5] ;
X = [] ;
X = [2] ;
X = [2, 3] ;
X = [2, 3, 4] ;
X = [2, 3, 4, 5] ;
X = [] ;
X = [3] ;
X = [3, 4] ;
X = [3, 4, 5] ;
X = [] ;
X = [4] ;
X = [4, 5] ;
X = [] ;
X = [5] ;
X = [] ;
fail.
*/

