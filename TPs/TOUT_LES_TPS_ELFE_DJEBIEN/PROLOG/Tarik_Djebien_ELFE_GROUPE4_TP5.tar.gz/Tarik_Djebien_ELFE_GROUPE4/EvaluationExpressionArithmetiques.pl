% Question 9

/*
?- X = 3+2.
X = 3+2 ;
fail.

on ne peut pas unifier l'expression 3+2 avec X.

?- X is 3+1.
X = 4 ;
fail.

on unifie l'expression 3+1 avec X donc X vaut 4.

?- X is 5+4*3-2+1.
X = 16 ;
fail.

on unifie l'expression 5+4*3-2+1 avec X donc X vaut 16 car on évqlue la multiplication en priorité.


?- 3+2 is X.
ERROR: is/2: Arguments are not sufficiently instantiated

on cherche à unifier l'expression X inconnue avec 3+2 qui est une expression.
> erreur

?- Y is X+1.
ERROR: is/2: Arguments are not sufficiently instantiated

Y est inconnue.

?- 3 is 2+1.
true.

on unifie l'expression 2+1 avec le nombre 3 ce qui donne un succés.

?- 4 is 2+1.
fail.

de meme 4 <> 2+1.

?- 2+1 is 2+1.
fail.

2+1 n'est pas un nombre mais une expression or seul la partie droite de is est evaluée.

?- help(is).
-Number is +Expr                                                  [ISO]
    True  if Number has successfully  been unified with the number  Expr
    evaluates to.   If Expr evaluates to a float that can be represented
    using  an integer (i.e,  the value is  integer and within the  range
    that can be  described by Prolog's integer representation),  Expr is
    unified with the integer value.

    Note  that normally, is/2 should be used with unbound  left operand.
    If equality is to be tested, =:=/2 should be used.  For example:

             ?- 1 is sin(pi/2).   Fails!.   sin(pi/2) evaluates
                                  to the float  1.0, which does
                                  not unify with the integer 1.
             ?- 1 =:= sin(pi/2).  Succeeds as expected.

true.

*/


% Question 10

long([],0).
long([_|L],N):- long(L,V), N is V+1.

% On a la longueur d'une liste vide qui vaut 0.
% Soit une liste L de reste R et de tete quelconque alors
% si on a V = longueur(R) et N=V+1 alors N est la longueur de L.

/*
ALGO :
  
  longueur(LISTE:L):INTEGER.
  DEBUT
    SI L = LISTEVIDE ALORS
      longueur = 0
    SINON
      longueur = 1 + longueur(Reste(L));
    FINSI
  FIN
*/

% Question 11

/*
?- trace.
Unknown message: query(yes)
[trace]  ?- long([1,2,3,4],Longeur).
   Call: (7) long([1, 2, 3, 4], _G325) ? creep
   Call: (8) long([2, 3, 4], _L197) ? creep
   Call: (9) long([3, 4], _L216) ? creep
   Call: (10) long([4], _L235) ? creep
   Call: (11) long([], _L254) ? creep
   Exit: (11) long([], 0) ? creep
^  Call: (11) _L235 is 0+1 ? creep
^  Exit: (11) 1 is 0+1 ? creep
   Exit: (10) long([4], 1) ? creep
^  Call: (10) _L216 is 1+1 ? creep
^  Exit: (10) 2 is 1+1 ? creep
   Exit: (9) long([3, 4], 2) ? creep
^  Call: (9) _L197 is 2+1 ? creep
^  Exit: (9) 3 is 2+1 ? creep
   Exit: (8) long([2, 3, 4], 3) ? creep
^  Call: (8) _G325 is 3+1 ? creep
^  Exit: (8) 4 is 3+1 ? creep
   Exit: (7) long([1, 2, 3, 4], 4) ? creep
Longeur = 4 ;
fail.

Ici on verifie lors du depilement des appel recursifs si les expressions evaluées sont bien égale avec le nombre
a gauche du is.
On aurait pu le faire directement a chaque appel recursifs.

*/

% Question 12

accLong([],Acc,Acc).
accLong([_|L],AccV,Res):- AccN is AccV+1, accLong(L,AccN,Res).
longueur(Liste,Res):-accLong(Liste,0,Res).

/*
AccN est un accumulateur permettant de stocker directement la longueur de la liste dans l'appel recursif pour le rendre
Terminal, On l'initalise donc dans son embaleur a zero car au debut la taille vaut zero ensuite pour chaque
élement on l'incremente de une unité.
*/

% Question 13

/*
[trace]  ?- longueur([1,2,3,4],Longueur).
   Call: (7) longueur([1, 2, 3, 4], _G325) ? creep
   Call: (8) accLong([1, 2, 3, 4], 0, _G325) ? creep
^  Call: (9) _L215 is 0+1 ? creep
^  Exit: (9) 1 is 0+1 ? creep
   Call: (9) accLong([2, 3, 4], 1, _G325) ? creep
^  Call: (10) _L235 is 1+1 ? creep
^  Exit: (10) 2 is 1+1 ? creep
   Call: (10) accLong([3, 4], 2, _G325) ? creep
^  Call: (11) _L255 is 2+1 ? creep
^  Exit: (11) 3 is 2+1 ? creep
   Call: (11) accLong([4], 3, _G325) ? creep
^  Call: (12) _L275 is 3+1 ? creep
^  Exit: (12) 4 is 3+1 ? creep
   Call: (12) accLong([], 4, _G325) ? creep
   Exit: (12) accLong([], 4, 4) ? creep
   Exit: (11) accLong([4], 3, 4) ? creep
   Exit: (10) accLong([3, 4], 2, 4) ? creep
   Exit: (9) accLong([2, 3, 4], 1, 4) ? creep
   Exit: (8) accLong([1, 2, 3, 4], 0, 4) ? creep
   Exit: (7) longueur([1, 2, 3, 4], 4) ? creep
Longueur = 4 ;
fail.

Ici on verifie directement si l'expression evaluée correspond a la longueur de la liste en premier parametre
directement avant chaque appel recursif. Ensuite il ne reste plus qu'a depiler la liste des appel pour obtenir le resultat.

*/


% Question 14

/*
Pour verifier qu'un predicat est bien recursif terminal on doit voir lors de la trace
si on a aucun autre appel ou verification a faire a la fin excepté le depilement des appels recursif
jusqu'a obtenir le resultat.(ie que des exit: sans interruption par d'autre call).
*/