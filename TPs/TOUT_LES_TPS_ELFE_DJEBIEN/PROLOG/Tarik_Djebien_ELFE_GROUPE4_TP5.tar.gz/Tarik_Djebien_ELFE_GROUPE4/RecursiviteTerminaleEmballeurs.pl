accoler([],L,L).
accoler([T|Q],L2,[T|L3]):-accoler(Q,L2,L3).

% Question 6

inv([],[]).
inv([T|Q],R):-inv(Q,InvQ),accoler(InvQ,[T],R).

/*
On a une inversion de Liste avec une recursivité non terminale,
etant donné que on rappel accoler aprés l'appel recursif:
  inverser une liste de tete T et de reste Q dans le resultat R revient à:
  inverser le reste Q dans le resultat InvQ et concatener le resultat InvQ avec la tete T dans R
*/

% Question 7

% le probleme intervient lorque l'on depile tout les appels recursif on doit a chaque fois effectuer 18 appels a accoler
% pour chaque élement de la liste.

accInv([T|Q],A,R):-accInv(Q,[T|A],R).
accInv([],A,A).
inverser(L,R):-accInv(L,[],R).

% Question 8

/*

  inverser([t,e,s,t],R).

  Etape                    Liste                       Accumulateur
  1                        [t,e,s,t]                   []
  2                        [e,s,t]                     [t]
  3                        [s,t]                       [e,t]
  4                        [t]                         [s,e,t]
  5                        []                          [t,s,e,t]

  [trace]  ?- inverser([t,e,s,t],R).
   Call: (7) inverser([t, e, s, t], _G325) ? creep
   Call: (8) accInv([t, e, s, t], [], _G325) ? creep
   Call: (9) accInv([e, s, t], [t], _G325) ? creep
   Call: (10) accInv([s, t], [e, t], _G325) ? creep
   Call: (11) accInv([t], [s, e, t], _G325) ? creep
   Call: (12) accInv([], [t, s, e, t], _G325) ? creep
   Exit: (12) accInv([], [t, s, e, t], [t, s, e, t]) ? creep
   Exit: (11) accInv([t], [s, e, t], [t, s, e, t]) ? creep
   Exit: (10) accInv([s, t], [e, t], [t, s, e, t]) ? creep
   Exit: (9) accInv([e, s, t], [t], [t, s, e, t]) ? creep
   Exit: (8) accInv([t, e, s, t], [], [t, s, e, t]) ? creep
   Exit: (7) inverser([t, e, s, t], [t, s, e, t]) ? creep
R = [t, s, e, t] ;
fail.

  
*/

