trainDirect(dunkerque,bergues).
trainDirect(bergues,hazebrouck).
trainDirect(hazebrouck,lens).
trainDirect(hazebrouck,lille).
trainDirect(lens,lille).
trainDirect(lens,douai).
trainDirect(douai,lille).
trainDirect(lille,lezennes).

% Question 1

voyagerDe_A(X,Y):-trainDirect(X,Y).
voyagerDe_A(X,Y):-trainDirect(X,Z),voyagerDe_A(Z,Y).

/*
?- voyagerDe_A(lens,lezennes).
true.

?- voyagerDe_A(bergues,lille).
true.

?- voyagerDe_A(lezennes,lille).
fail.

*/

% Question 2

voyagerDe_A(Y,X):-voyagerDe_A(X,Y).

/*
?- voyagerDe_A(lezennes,lille).
true.

*/


% Question 3
% route(+villeDepart,+villeDestination,?Liste)

route(X,Y,[X|ResteL]):-voyagerDe_A(X,Y),route(X,Y,ResteL).