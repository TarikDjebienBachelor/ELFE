% Question 15

ajouteUn([],[]).
ajouteUn([H|T],[H1|T1]):-ajouteUn(T,T1),H1 is H+1.

/*
?- ajouteUn([1,2,3],X).
X = [2, 3, 4] ;
fail.

Le resultat desiré est bien obtenu.

*/

% Question 16

/*
?- trace.
Unknown message: query(yes)
[trace]  ?- ajouteUn([1,2,3],X).
   Call: (7) ajouteUn([1, 2, 3], _G322) ? creep
   Call: (8) ajouteUn([2, 3], _G396) ? creep
   Call: (9) ajouteUn([3], _G399) ? creep
   Call: (10) ajouteUn([], _G402) ? creep
   Exit: (10) ajouteUn([], []) ? creep
^  Call: (10) _G401 is 3+1 ? creep
^  Exit: (10) 4 is 3+1 ? creep
   Exit: (9) ajouteUn([3], [4]) ? creep
^  Call: (9) _G398 is 2+1 ? creep
^  Exit: (9) 3 is 2+1 ? creep
   Exit: (8) ajouteUn([2, 3], [3, 4]) ? creep
^  Call: (8) _G395 is 1+1 ? creep
^  Exit: (8) 2 is 1+1 ? creep
   Exit: (7) ajouteUn([1, 2, 3], [2, 3, 4]) ? creep
X = [2, 3, 4] ;
fail.

Non il n'est pas recursif terminale.

*/

ajouteUnTerm([],[]).
ajouteUnTerm([H|T],[H1|T1]):-H1 is H+1,ajouteUnTerm(T,T1).

/*
?- trace.
Unknown message: query(yes)
[trace]  ?- ajouteUnTerm([1,2,3],X).
   Call: (7) ajouteUnTerm([1, 2, 3], _G322) ? creep
^  Call: (8) _G395 is 1+1 ? creep
^  Exit: (8) 2 is 1+1 ? creep
   Call: (8) ajouteUnTerm([2, 3], _G396) ? creep
^  Call: (9) _G401 is 2+1 ? creep
^  Exit: (9) 3 is 2+1 ? creep
   Call: (9) ajouteUnTerm([3], _G402) ? creep
^  Call: (10) _G407 is 3+1 ? creep
^  Exit: (10) 4 is 3+1 ? creep
   Call: (10) ajouteUnTerm([], _G408) ? creep
   Exit: (10) ajouteUnTerm([], []) ? creep
   Exit: (9) ajouteUnTerm([3], [4]) ? creep
   Exit: (8) ajouteUnTerm([2, 3], [3, 4]) ? creep
   Exit: (7) ajouteUnTerm([1, 2, 3], [2, 3, 4]) ? creep
X = [2, 3, 4] ;
fail.

Ici c'est recursif terminale on depile juste les appels pour obtenir le resultat
,les test on était fait avant l'appel recursif.
*/

% Question 16 bis

accMax([H|T],A,Max):-H>A,accMax(T,H,Max).
accMax([H|T],A,Max):-H=<A,accMax(T,A,Max).
accMax([],A,A).

% Question 17

/*
Recherche d'un element maximal dans une structure de donnée linéraire de Liste:
  on teste le premier élement de la liste,
    si celui ci est plus grand que l'accumulateur A on affecte la tete H dans A et on poursuit la recherche sur le Reste.
    sinon on poursuit la recherche avec le meme accumulateur.
  Lorsque la liste est parcouru elle est alors vide et on renvoi l'accumulateur qui contient l'element maximum.
*/

% Question 18


accMin([H|T],A,Min):-H>=A,accMin(T,A,Min).
accMin([H|T],A,Min):-H<A,accMin(T,H,Min).
accMin([],A,A).
% Question 19
min(Liste,Res):-accMin(Liste,100000000,Res).

/*
?- min([4,7,2,3,12],Res).
Res = 2 ;
fail.

*/

% Question 20

multiScal(_,[],[]).
multiScal(X,[TeteL|ResteL],[H1|T1]):-H1 is TeteL*X,multiScal(X,ResteL,T1).


/*
?- multiScal(2,[1,2,3],Resultat).
Resultat = [2, 4, 6] ;
fail.

?- multiScal(0,[1,2,3],Resultat).
Resultat = [0, 0, 0] ;
fail.

?- multiScal(4,[],Resultat).
Resultat = [] ;
fail.

?- trace.
Unknown message: query(yes)
[trace]  ?- multiScal(-4,[1,2,3],Resultat).
   Call: (7) multiScal(-4, [1, 2, 3], _G323) ? creep
^  Call: (8) _G400 is 1* -4 ? creep
^  Exit: (8) -4 is 1* -4 ? creep
   Call: (8) multiScal(-4, [2, 3], _G401) ? creep
^  Call: (9) _G406 is 2* -4 ? creep
^  Exit: (9) -8 is 2* -4 ? creep
   Call: (9) multiScal(-4, [3], _G407) ? creep
^  Call: (10) _G412 is 3* -4 ? creep
^  Exit: (10) -12 is 3* -4 ? creep
   Call: (10) multiScal(-4, [], _G413) ? creep
   Exit: (10) multiScal(-4, [], []) ? creep
   Exit: (9) multiScal(-4, [3], [-12]) ? creep
   Exit: (8) multiScal(-4, [2, 3], [-8, -12]) ? creep
   Exit: (7) multiScal(-4, [1, 2, 3], [-4, -8, -12]) ? creep
Resultat = [-4, -8, -12] ;
   Redo: (9) multiScal(-4, [3], _G407) ? creep
   Redo: (8) multiScal(-4, [2, 3], _G401) ? creep
   Redo: (7) multiScal(-4, [1, 2, 3], _G323) ? creep
fail.
*/

% Question 21


multiScalEfficace(X,[TeteL|ResteL],[H1|T1]):-H1 is TeteL*X,!,multiScal(X,ResteL,T1).
multiScalEfficace(_,[],[]).

/*
On peut l'ameliorer en rajoutant la coupure ! avant l'appel recursif pour eviter les backtracking aprés le resultat
et on obtient :


?- trace.
Unknown message: query(yes)
[trace]  ?- multiScalEfficace(-4,[1,2,3],Resultat).
   Call: (7) multiScalEfficace(-4, [1, 2, 3], _G323) ? creep
^  Call: (8) _G400 is 1* -4 ? creep
^  Exit: (8) -4 is 1* -4 ? creep
   Call: (8) multiScalEfficace(-4, [2, 3], _G401) ? creep
^  Call: (9) _G406 is 2* -4 ? creep
^  Exit: (9) -8 is 2* -4 ? creep
   Call: (9) multiScalEfficace(-4, [3], _G407) ? creep
^  Call: (10) _G412 is 3* -4 ? creep
^  Exit: (10) -12 is 3* -4 ? creep
   Call: (10) multiScalEfficace(-4, [], _G413) ? creep
   Exit: (10) multiScalEfficace(-4, [], []) ? creep
   Exit: (9) multiScalEfficace(-4, [3], [-12]) ? creep
   Exit: (8) multiScalEfficace(-4, [2, 3], [-8, -12]) ? creep
   Exit: (7) multiScalEfficace(-4, [1, 2, 3], [-4, -8, -12]) ? creep
Resultat = [-4, -8, -12] ;
fail.


*/