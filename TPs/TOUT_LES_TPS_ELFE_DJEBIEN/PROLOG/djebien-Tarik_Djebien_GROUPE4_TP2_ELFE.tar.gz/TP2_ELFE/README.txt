README : 

// Auteur : Djebien Tarik
// Date    : 29 janvier 2011
// Objet  : programmation logique - Unification et Resolution

Ci-Joint le TP numero 2 de Programmation logique de ELFE, tout est fonctionnel :

Arborescence de l'archive Tarik_Djebien_GROUPE4.tar.gz :
    |
    |_____README.txt
    |_____unification.pl resolution.pl 
    |_____motCroise.pl generateurphrase.pl
    
Remarques:

Les fichiers sources *.pl sont édités sous Emacs.

Pour les commentaires :

tarik.djebien@etudiant.univ-lille1.fr

Cordialement.
