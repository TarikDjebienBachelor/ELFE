% 1 Listes en Prolog

% Question 1

/*
?- [H|T]=[mia,vincent,jules].
H = mia,
T = [vincent, jules] ;
fail.

?- [H|T]=[].
fail.

?- [X,Y|T]=[mia,vincent,jules].
X = mia,
Y = vincent,
T = [jules] ;
fail.

?- [a,b,c,d]=[a,[b,c,d]].
fail.

?- [a,b,c,d]=[a|[b,c,d]].
true.

?- [a,b,c,d]=[a,b,[c,d]].
fail.

?- [a,b,c,d]=[a,b|[c,d]].
true.

?- [a,b,c,d]=[a,b,c,d|[]].
true.

?- []=[_].
fail.

?- []=_.
true.

?- []=X.
X = [] ;
fail.
*/

% Question 2

/* longMinDeux(X) est vrai ssi X est une liste de longueur au moins 2 */
longMinDeux(L):-L=[_,_|_].