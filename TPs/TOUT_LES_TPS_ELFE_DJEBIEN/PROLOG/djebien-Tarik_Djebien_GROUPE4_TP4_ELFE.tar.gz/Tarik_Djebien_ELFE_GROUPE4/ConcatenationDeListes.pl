% 4 CONCATENATION DE LISTES

% Question 10
accoler([],L,L).
accoler([T|Q],L2,[T|L3]):-accoler(Q,L2,L3).

/*

?- accoler([],[],X).
X = [] ;
fail.

?- accoler([2],[],X).
X = [2] ;
fail.

?- accoler([2],[1],X).
X = [2, 1] ;
fail.

?- accoler([1,4,ok],[ko,4,2],X).
X = [1, 4, ok, ko, 4, 2] ;
fail.

?- accoler([1,4],[4,2],[1,4,4,2]).
true.

*/

% Question 11

/*
En lancant une requete comme ceci sur une liste de départ L = [1,2,3,4] par exemple:
?- accoler(L1,L2,[1,2,3,4]).
L1 = [],
L2 = [1, 2, 3, 4] ;
L1 = [1],
L2 = [2, 3, 4] ;
L1 = [1, 2],
L2 = [3, 4] ;
L1 = [1, 2, 3],
L2 = [4] ;
L1 = [1, 2, 3, 4],
L2 = [] ;
fail.
*/

% Question 12

% accoler(L1,L2,L) est vrai si et seulement si L est la concaténation de la liste L1 suivi de la liste L2.

% Question 13

/* cf arbreResolutionQ13.pdf */                                                                                
                                                          
                                                          
% Question 14
/*
[trace]  ?- accoler([je,te,dis],[c,est,facile],X).
   Call: (7) accoler([je, te, dis], [c, est, facile], _G332) ? creep
   Call: (8) accoler([te, dis], [c, est, facile], _G416) ? creep
   Call: (9) accoler([dis], [c, est, facile], _G419) ? creep
   Call: (10) accoler([], [c, est, facile], _G422) ? creep
   Exit: (10) accoler([], [c, est, facile], [c, est, facile]) ? creep
   Exit: (9) accoler([dis], [c, est, facile], [dis, c, est, facile]) ? creep
   Exit: (8) accoler([te, dis], [c, est, facile], [te, dis, c, est, facile]) ? creep
   Exit: (7) accoler([je, te, dis], [c, est, facile], [je, te, dis, c, est, facile]) ? creep
X = [je, te, dis, c, est, facile] ;
fail.

EXPLICATION :
voir le detail d'instanciation des variables sur le schema de arbreResolution.pdf
*/