type lambda_terme =
  | Var of string                          (*  variables  *)
  | Abstr of (string * lambda_terme)       (* abstraction *)
  | Appl of ( lambda_terme * lambda_terme) (* application *)

(* Question 7 *)
let t0 = Var "x" ;;
let t1 = Var "y" ;;
let t2 = Appl (t0, t1) ;;
let i = Abstr ("lambdaX",t1) ;; let t3 = i;;
let k = Abstr ("lambdaXY",t0) ;; let t4 = k;;
let kStar = Abstr ("lambdaXY",t1) ;; let t5 = kStar;;
let s = Abstr ("lambdaXYZ",Appl(t0,Appl(Var "z",Appl(t1,Var "z")))) ;; let t6 = s;;

let omega = Appl (Abstr("lambdaX",Appl(t0,t0)),Abstr("lambdaX",Appl(t0,t0)));; let t7 = omega;;
let y = Abstr("lambdaF",Appl(Abstr("lambdaX",Appl(Var "f",Appl(t0,t0))),Abstr("lambdaX",Appl(Var "f",Appl(t0,t0)))));;
let t8 = y;;

let rec lambdaterme_en_chaine (l:lambda_terme):string =
   match l with
     | Var s -> s
     | Abstr(c,t)  -> "\\"^c^"."^(lambdaterme_en_chaine(t))
     | Appl(t1,t2) -> "("^lambdaterme_en_chaine(t1)^" "^lambdaterme_en_chaine(t2)^")"



(*
val lambdaterme_en_chaine : lambda_terme -> string = <fun>
# lambdaterme_en_chaine t3 ;;    
- : string = "\\lambdaX.y"
# lambdaterme_en_chaine t2 ;;    
- : string = "(x y)"
# lambdaterme_en_chaine t3 ;;
- : string = "\\lambdaX.y"
# lambdaterme_en_chaine t4 ;;
- : string = "\\lambdaXY.x"
# lambdaterme_en_chaine t6 ;;
- : string = "\\lambdaXYZ.(x (z (y z)))"
# lambdaterme_en_chaine t8 ;;
- : string = "\\lambdaF.(\\lambdaX.(f (x x)) \\lambdaX.(f (x x)))"
*)

let imprimer_lambdaterme f t = Format.pp_print_string f (lambdaterme_en_chaine t)

(*
# i ;;
- : lambda_terme = \lambdaX.y
# k ;;
- : lambda_terme = \lambdaXY.x
# kStar ;;
- : lambda_terme = \lambdaXY.y
# s ;;
- : lambda_terme = \lambdaXYZ.(x (z (y z)))
# omega ;;
- : lambda_terme = (\lambdaX.(x x) \lambdaX.(x x))
# y ;;
- : lambda_terme = \lambdaF.(\lambdaX.(f (x x)) \lambdaX.(f (x x)))
*)


(* question 9 *)

(**
   [union e1 e2] = reunion des deux ensembles [e1] et [e2].
   Le resultat est sans doublons.
*)
let rec union e1 e2 =
  match e1 with
    | x1::e1' ->
      let res = union e1' e2 in
      if List.mem x1 e2 then
	res
      else 
	x1::res
    | _ -> e2

(**
   [retire x e] = ensemble [e] sans [x].
*)
let rec retire x e = 
  match e with
    | y::e' ->
      if x = y then
	retire x e'
      else 
	y::(retire x e')
    | _ -> []


let rec moins e1 e2 =
  match e2 with
    | x2::e2' ->
      moins (retire x2 e1) e2'
    | _ -> e1

(**
   [var_libres t] = ensemble (liste) des variables libres de [t].
*)
let rec var_libres t =
  match t with
    | Var x -> [x]
    | Appl (t1,t2) ->
      let var1 = var_libres t1
      and var2 = var_libres t2 in
      union var1 var2
    | Abstr (x, t') ->
      let res = var_libres t' in
      moins res [x]

(**
   [var_liees t] = ensemble (liste) des variables liees de [t].
*)
let rec var_liees t = 
  match t with 
    | Var _ -> []
    | Appl (t1,t2) ->
      let var1 = var_liees t1
      and var2 = var_liees t2 in
      union var1 var2
    | Abstr (x,t') ->
      let res = var_liees t' 
      and libres = var_libres t' in
      if List.mem x libres then
	union res [x]
      else 
	res




(*
# var_liees y ;; 
- : string list = []
# var_libres y ;;                
- : string list = ["f"; "x"]
*)
