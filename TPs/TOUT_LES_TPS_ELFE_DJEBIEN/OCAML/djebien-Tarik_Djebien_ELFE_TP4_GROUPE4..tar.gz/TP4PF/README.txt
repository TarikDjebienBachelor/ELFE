README : 

// Auteur : Djebien Tarik
// Date    : 20 mars 2011
// Objet  : programmation fonctionnelle - TP4 Ocaml Lambda calcul filtrage

Ci-Joint le TP numero 4 de Programmation fonctionnelle de ELFE :

Arborescence de l'archive Tarik_Djebien_ELFE_GROUPE4.tar.gz :
    |
    |_____README.txt
    |_____Liste.ml
    |_____negation.ml
    |_____quotient.ml
    |_____lambdaCalcul.ml 

Pour les commentaires :

tarik.djebien@etudiant.univ-lille1.fr

Cordialement.
