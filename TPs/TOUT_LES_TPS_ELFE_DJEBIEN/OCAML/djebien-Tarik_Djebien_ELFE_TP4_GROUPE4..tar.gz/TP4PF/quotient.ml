type int_etendu = Non_defini | Int of int ;;

let quotient (x: int)
             (y: int):int_etendu = 
      if y = 0 then 
        Non_defini
      else 
        Int (x / y) ;;

(*
# quotient 17 3 ;;
- : int_etendu = Int 5
# quotient 17 0 ;;
- : int_etendu = Non_defini
*) 

let quotient_etendu n1 n2 =
     match n1,n2 with
       | _ , Int 0 -> Non_defini
       | Int x, Int y -> Int(x/y)
       | _ , _ -> Non_defini
