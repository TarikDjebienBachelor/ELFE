type booleen = Vrai | Faux ;;

let not = function
  | Vrai -> Faux
  | Faux -> Vrai

(*
val not : booleen -> booleen = <fun>
# not Vrai ;;
- : booleen = Faux
# not Faux ;;
- : booleen = Vrai
*)
