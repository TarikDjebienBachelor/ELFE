type liste_entiers = Vide | Cons of (int*liste_entiers) ;;
type int_etendu = Non_defini | Int of int ;;

let plus n1 n2 =
   match n1,n2 with
    | Int n, Int p -> Int (n+p)
    | _ -> Non_defini


(*	Cons(1,Cons(2,(Cons(3,Cons(1,Vide))))) ;; *)

let rec longueur (l : liste_entiers):int = 
  match l with
  | Vide -> 0
  | Cons(_,r) -> 1 + (longueur r)

let rec rang v l =
  match l with
  | Vide -> Non_defini
  | Cons(tete,reste) -> if v = tete then 
                              (Int 0) 
                            else 
                              plus (Int 1) (rang v reste)
 
