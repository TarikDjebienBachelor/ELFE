(* Exercice 1 *)

(* Fonction nth *)
let rec nth l p =
    match l with 
      | x::r -> if p=0 then x else nth r (p-1)
      | _    -> failwith "nth: la position doit etre inferieur a la longueur de la liste"

(*
val nth : 'a list -> int -> 'a = <fun>
# nth [1;2;3;4] 0 ;;    
- : int = 1
# nth [1;2;3;4] 3 ;;    
- : int = 4
# nth [1;2;3;4] 4 ;;    
Exception:
Failure "nth: la position doit etre inferieur a la longueur de la liste".
*)


(* Fonction append *)
let rec append l1 l2 = 
     match (l1,l2) with
       | ([],l2)-> l2
       | (l1,[])-> l1
       | (x1::r1,l2)->x1::(append r1 l2)

(*
val append : 'a list -> 'a list -> 'a list = <fun>
# append [1;2;3;4] [5;6] ;;
- : int list = [1; 2; 3; 4; 5; 6]
# append [] [1;2;3] ;;
- : int list = [1; 2; 3]
# append [1;2;3] [] ;;     
- : int list = [1; 2; 3]
*)

(* Fonction map *)
let rec map f l =
     match (f,l) with
       | (_,[])->[]
       | (f,x::r)-> (f x):: map f r

(*
val map : ('a -> 'b) -> 'a list -> 'b list = <fun>
# map (function x -> x*x) [1;2;3;4];;
- : int list = [1; 4; 9; 16]
*)

(* Fonction flatten *)
let rec flatten l =
     match l with 
       | [] -> []
       | (x::r) -> (append x (flatten r))
(*
val flatten : 'a list list -> 'a list = <fun>
# flatten [[1;2;3];[4;5];[6;7]];;
- : int list = [1; 2; 3; 4; 5; 6; 7]
*)

(* Exercice 2 *)

(*
Si l est une 'a list alors
let x = nth l est de type : 
val int -> 'a

On verifie :
# let l = [] ;;   
val l : 'a list = []
# let x = nth l ;;
val x : int -> 'a = <fun>
*)


(* Exercice 3 *)

let rec somme l =
    match l with
      | [] -> 0
      | (x::r)-> x + somme r

(*
val somme : int list -> int = <fun>
# somme [1;2;3;4] ;;
- : int = 10
# somme [1;1;1] ;;  
- : int = 3
# somme [] ;;     
- : int = 0
*)

let rec length l =
    match l with
      | [] -> 0
      | (x::r)-> map (function y -> 1) x 
