% 3 COMBINAISONS

% Question 7

combine1([],[],[]).
combine1([TeteX|ResteX],[TeteY|ResteY],[TeteX,TeteY|ResteZ]):-combine1(ResteX,ResteY,ResteZ).

% Question 8

combine2([],[],[]).
combine2([TeteX|ResteX],[TeteY|ResteY],[[TeteX,TeteY]|ResteZ]):-combine2(ResteX,ResteY,ResteZ).

% Question 9

combine3([],[],[]).
combine3([TeteX|ResteX],[TeteY|ResteY],[paire(TeteX,TeteY)|ResteZ]):-combine3(ResteX,ResteY,ResteZ).