% 5 Ensembles

% Question 15

member(X,[X|_]).
member(X,[_|Y]):-member(X,Y).

/* inclusion(L1,L2) vrai ssi L1 c L2 */
inclusion([TeteL1|ResteL1],L2):-member(TeteL1,L2),inclusion(ResteL1,L2).
inclusion([],_).


% Question 16

/* notmember(E,L) vrai ssi E n'appartient pas à L */

notmember(E,L):- member(E,L),!,fail.
notmember(_,_).

% Question 17

% prédicat union(Ens1,Ens2,U) satisfait lorsque l'ensemble U donnée est l’union des
% ensembles Ens1,Ens2.

% union(+Ens1, +Ens2, ?U)
union([],Ens2, Ens2).
union([X|Ens1], Ens2,[X|U]) :-
    \+ member(X,Ens2),
    union(Ens1,Ens2,U).
union([X|Ens1], Ens2,U) :-
    member(X,Ens2),
    union(Ens1,Ens2,U).

% Question 18

% prédicat intersection(Ens1,Ens2,I) satisfait lorsque l'ensemble I donnée est l’intersection des
% ensembles Ens1,Ens2.

% intersection(+Ens1, +Ens2, ?I)
intersection([],_,[]).
intersection([X|Ens1], Ens2,[X|I]) :-
    member(X,Ens2),
    intersection(Ens1,Ens2,I).
intersection([X|Ens1], Ens2,I) :-
    \+ member(X,Ens2),
    intersection(Ens1,Ens2,I).