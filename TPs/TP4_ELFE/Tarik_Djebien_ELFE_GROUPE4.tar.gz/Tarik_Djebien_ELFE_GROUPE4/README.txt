README : 

// Auteur : Djebien Tarik
// Date    : 9 février 2011
// Objet  : programmation logique - Listes 

Ci-Joint le TP numero 4 de Programmation logique de ELFE, tout est fonctionnel :

Arborescence de l'archive Tarik_Djebien_ELFE_GROUPE4.tar.gz :
    |
    |_____README.txt
    |_____ListesProlog.pl (source PROLOG édité sous Emacs sur la Partie I du TP).
    |_____listeEtRecursion.pl (source PROLOG édité sous Emacs sur la Partie II du TP).
    |_____combinaisons.pl (source PROLOG édité sous Emacs sur la Partie III du TP).
    |_____ConcatenationDeListes.pl (source PROLOG édité sous Emacs sur la Partie IV du TP).
    |_____arbreResolutionQ13.pdf (Dessin de l’arbre de résolution de la requête accoler ([ je , te , dis ],[ c, est , facile ], X). ).
    |_____Ensembles.pl (source PROLOG édité sous Emacs sur la Partie V du TP).

Pour les commentaires :

tarik.djebien@etudiant.univ-lille1.fr

Cordialement.
