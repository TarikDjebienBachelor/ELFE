% 2 Listes et recursion

% Question 3

memelong([],[]).
memelong([_|X],[_|Y]):-memelong(X,Y).

% Question 4

/* member(X,Y) vrai ssi X est un element de la liste Y */

/*
 member(e:ELEMENT,L:LISTE):BOOLEAN;
 begin
  if (L = LISTEVIDE) then
    member := FALSE
  else if (tete(L)=e) then
    member := TRUE
  else
    member := member(e,reste(L));
 end;
*/

member(X,[X|_]):-!.
member(X,[_|Z]):-member(X,Z).

% Question 5
deuxFois([],[]).
deuxFois([E|ResteX],[E,E|ResteY]):-deuxFois(ResteX,ResteY).

