README : 

// Auteur : Djebien Tarik
// Date    : 3 février 2011
// Objet  : programmation logique - Resolution et Récursivité

Ci-Joint le TP numero 3 de Programmation logique de ELFE, tout est fonctionnel :

Arborescence de l'archive Tarik_Djebien_ELFE_GROUPE4.tar.gz :
    |
    |_____README.txt
    |_____entierDePeano.pl (source PROLOG édité sous Emacs sur la Partie II du TP avec quelques prédicats supplémentaires)
    |_____Genealogie.pdf (Compte rendu de la partie I du TP)
    

Pour les commentaires concernant ma question sur la resolution de PROLOG:

tarik.djebien@etudiant.univ-lille1.fr

Merci d'avance pour vos explications,
Cordialement.
